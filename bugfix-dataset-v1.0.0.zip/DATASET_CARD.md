---
license: other
task_categories: [text-generation]
tags: [code, bug-fix, software-engineering, swe-bench]
pretty_name: Verified Python bug fixes
---

# Verified Python bug fixes

Real bugs from open-source Python projects: the issue that reported each one,
the pull request that fixed it, the fix split into a code patch and a test
patch, and **evidence from running the tests**: the new tests fail without
the fix and pass with it.

Generated 2026-11-02 by [bugfix-dataset](https://github.com/nexusknox/bugfix-dataset).

## At a glance

- **32 records** released (verified records only, quality score ≥ 0)
- **1002 tests** that fail before the fix and pass after it
- Average quality score: **91.0/100**
- Built from 80 candidates; verification results:
  not_run 38, verified 32, failed 8, error 2

| Repository | Records |
|---|---:|
| pallets/flask | 18 |
| pytest-dev/pytest | 14 |

## How it was made

1. **Mined** merged pull requests from permissively licensed Python repositories
   (MIT, Apache-2.0, BSD, ISC and similar) through the GitHub API. A PR is kept
   only if GitHub links it to an issue it closes, it changes Python source and
   tests, it changes no other language's source, and it's a focused fix
   (at most 300 changed lines and 5 files).
2. **Split** each fix into a code patch and a test patch.
3. **Verified** each record in a fresh Docker container: the repository at the
   commit before the fix, with dependencies installed **as they were on the
   day the fix was merged** (`uv --exclude-newer`), on the Python version
   current at that time. The test patch is applied alone (the new tests must
   fail), then the fix (they must pass, and no previously passing test may break).
4. **Cleaned**: emails and secrets removed from issue text, PR text and logs;
   records whose patches contain secrets dropped; duplicate fixes (e.g.
   backports) removed by fingerprint.

## Files

| File | Contents |
|---|---|
| `dataset.jsonl` | One record per line: issue, PR, commits, `code_patch`, `test_patch`, `fail_to_pass`, `pass_to_pass`, quality score with reasons |
| `test_logs.jsonl` | pytest output before and after the fix, per record |
| `swebench.jsonl` | The same records with SWE-bench field names (`instance_id`, `patch`, `test_patch`, `problem_statement`, `FAIL_TO_PASS`, …) |
| `stats.json` | The numbers on this card |

## Quality score

Each record has a 0-100 score with its reasons: +50 verified, up to +20 for a
detailed issue description, up to +15 for a small fix, up to +15 for a fix in
one file.

## Limitations

- Python projects tested with pytest only.
- Test IDs use pytest's JUnit naming (`tests.test_app::test_name`), not file
  paths (`tests/test_app.py::test_name`).
- If the new tests import something that only exists after the fix, the whole
  test file fails to load before it, so every test in that file is counted as
  fail-to-pass, not only the tests about the bug.
- Very old commits (before ~2019) often can't be installed any more and are
  left out, which skews the data towards recent code.
- Fixes for bugs that only appear on a newer Python than the one chosen for
  their date can show as "tests already pass" and are left out.
- Issue text is written by people and may be informal, incomplete or wrong.
- Verification shows the new tests pass; it does not prove the fix is the
  best possible one.

## Licences and attribution

Every record keeps the licence of the repository it came from, in its
`license` field. Code in `code_patch` and `test_patch` remains under that
licence and copyright; reuse must follow it (for example, MIT and BSD require
keeping the copyright notice, and Apache-2.0 also requires noting changes).

| Repository | Licence |
|---|---|
| [pallets/flask](https://github.com/pallets/flask) | BSD-3-Clause |
| [pytest-dev/pytest](https://github.com/pytest-dev/pytest) | MIT |

## Personal information

Email addresses and credentials are removed from issue text, PR text, commit
messages and logs. GitHub usernames may remain in issue and PR text.
